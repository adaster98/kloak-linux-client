(async () => {
    const ADDON_ID = 'developer-toolkit';

    // Fetch config once on startup
    let config = { showIdsInChat: true };
    try {
        if (window.electronAPI && window.electronAPI.getAddonConfig) {
            const savedConfig = await window.electronAPI.getAddonConfig(ADDON_ID);
            if (savedConfig && typeof savedConfig.showIdsInChat === 'boolean') {
                config.showIdsInChat = savedConfig.showIdsInChat;
            }
        }
    } catch (e) { console.error(`[${ADDON_ID}] Failed to load config:`, e); }

    const STYLE_CONFIG = {
        msgId: 'kloak-injected-msg-id text-[10px] text-muted-foreground/40 font-mono mt-1 select-text transition-colors hover:text-muted-foreground/80',
        userId: 'kloak-injected-user-id text-[10px] text-muted-foreground/40 font-mono ml-2 mr-1 select-text transition-colors hover:text-muted-foreground/80'
    };

    const SUPABASE_URL = "https://foquucurnwpqcvgqukpz.supabase.co";

    // Global State
    let domObserver = null;
    let rightClickObserver = null;
    let originalFetch = null;
    let lastRightClickedMessageId = null;

    // Data Caches
    const messageCache = new Map();
    let apiHeaders = {};

    // Network Interceptor
    const setupInterceptor = () => {
        if (!originalFetch) originalFetch = window.fetch;

        window.fetch = async (...args) => {
            const [resource, reqConfig] = args;

            if (typeof resource === 'string' && resource.startsWith(SUPABASE_URL)) {
                if (reqConfig && reqConfig.headers && reqConfig.headers.apikey) {
                    apiHeaders = reqConfig.headers;
                }
            }

            const response = await originalFetch(...args);

            if (typeof resource === 'string' && resource.includes('/rest/v1/messages')) {
                response.clone().json().then(data => {
                    if (Array.isArray(data)) {
                        data.forEach(msg => messageCache.set(msg.id, msg));
                    } else if (data && data.id) {
                        messageCache.set(data.id, data);
                    }

                    if (config.showIdsInChat) {
                        setTimeout(() => {
                            document.querySelectorAll('div[id^="message-"]').forEach(processMessage);
                        }, 50);
                    }
                }).catch(() => {});
            }
            return response;
        };
    };

    const removeInterceptor = () => {
        if (originalFetch) {
            window.fetch = originalFetch;
            originalFetch = null;
        }
    };

    // DOM injection
    const processMessage = (msgNode) => {
        if (!config.showIdsInChat) return; // Respect the toggle

        const fullMsgId = msgNode.id;
        if (!fullMsgId || !fullMsgId.startsWith('message-')) return;
        const msgId = fullMsgId.replace('message-', '');

        if (!msgNode.dataset.msgIdInjected) {
            const contentContainer = msgNode.querySelector('.flex-1.min-w-0.overflow-hidden');
            if (contentContainer) {
                const idDiv = document.createElement('div');
                idDiv.className = STYLE_CONFIG.msgId;
                idDiv.textContent = `msg: ${msgId}`;
                contentContainer.appendChild(idDiv);
                msgNode.dataset.msgIdInjected = 'true';
            }
        }

        if (!msgNode.dataset.usrIdInjected) {
            let userId = null;

            const cachedMsg = messageCache.get(msgId);
            if (cachedMsg && cachedMsg.user_id) userId = cachedMsg.user_id;

            if (!userId) {
                const avatarImg = msgNode.querySelector('img[src*="/avatars/"]');
                if (avatarImg) {
                    const match = avatarImg.src.match(/\/avatars\/([^\/]+)\//);
                    if (match) userId = match[1];
                }
            }

            if (userId) {
                const headerContainer = msgNode.querySelector('.flex.items-baseline.gap-2');
                if (headerContainer) {
                    const uidSpan = document.createElement('span');
                    uidSpan.className = STYLE_CONFIG.userId;
                    uidSpan.textContent = `usr: ${userId}`;

                    const timestamp = headerContainer.querySelector('.text-muted-foreground');
                    if (timestamp) headerContainer.insertBefore(uidSpan, timestamp);
                    else headerContainer.appendChild(uidSpan);

                    msgNode.dataset.usrIdInjected = 'true';
                }
            }
        }
    };

    // Developer Modal UI
    const showDeveloperModal = (user) => {
        const overlay = document.createElement('div');
        overlay.style.cssText = 'display: flex; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.85); z-index: 9999999; justify-content: center; align-items: center;';

        const formatDate = (dateStr) => dateStr ? new Date(dateStr).toLocaleString() : 'N/A';
        const avatarSrc = user.avatar_url || 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjNTI1MjViIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBhdGggZD0iTTE5IDIxdi0yYTQgNCAwIDAgMC00LTRIOSBhNCA0IDAgMCAwLTQgNHYyIi8+PGNpcmNsZSBjeD0iMTIiIGN5PSI3IiByPSI0Ii8+PC9zdmc+';

        overlay.innerHTML = `
        <div style="background: #0f0f0f; border: 1px solid #2a2a2a; border-radius: 12px; width: 450px; overflow: hidden; font-family: sans-serif; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.7); animation: gentleShake 0.4s ease-out forwards;">
        <div style="padding: 24px; border-bottom: 1px solid #2a2a2a; display: flex; align-items: center; gap: 16px;">
        <img src="${avatarSrc}" style="width: 64px; height: 64px; border-radius: 50%; background: #161616; object-fit: cover; border: 1px solid #2a2a2a;">
        <div style="min-width: 0; flex: 1;">
        <h2 style="margin: 0 0 4px 0; color: #E0E0E0; font-size: 20px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${user.display_name || user.username}</h2>
        <span style="color: #949494; font-size: 14px; background: #1c1c1f; padding: 4px 8px; border-radius: 6px; border: 1px solid #27272a;">@${user.username}</span>
        ${user.status === 'online' ? '<span style="color: #10b981; font-size: 13px; margin-left: 8px;">● Online</span>' : ''}
        </div>
        </div>

        <div style="padding: 24px; display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <div style="grid-column: span 2;">
        <label style="color: #71717a; font-size: 11px; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px;">User ID</label>
        <div style="color: #10b981; font-family: monospace; font-size: 13px; margin-top: 6px; user-select: text; background: #161616; padding: 8px; border-radius: 6px; border: 1px solid #2a2a2a;">${user.id}</div>
        </div>

        <div>
        <label style="color: #71717a; font-size: 11px; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px;">Last Seen</label>
        <div style="color: #E0E0E0; font-size: 13px; margin-top: 6px;">${formatDate(user.last_seen)}</div>
        </div>

        <div>
        <label style="color: #71717a; font-size: 11px; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px;">Account Created</label>
        <div style="color: #E0E0E0; font-size: 13px; margin-top: 6px;">${formatDate(user.created_at)}</div>
        </div>

        ${user.custom_status ? `
            <div style="grid-column: span 2;">
            <label style="color: #71717a; font-size: 11px; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px;">Custom Status</label>
            <div style="color: #E0E0E0; font-size: 13px; margin-top: 6px; background: #161616; padding: 8px; border-radius: 6px; border: 1px solid #2a2a2a;">${user.custom_status}</div>
            </div>` : ''}

            ${user.bio ? `
                <div style="grid-column: span 2;">
                <label style="color: #71717a; font-size: 11px; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px;">Bio</label>
                <div style="color: #E0E0E0; font-size: 13px; margin-top: 6px; line-height: 1.5; background: #161616; padding: 12px; border-radius: 6px; border: 1px solid #2a2a2a; white-space: pre-wrap;">${user.bio}</div>
                </div>` : ''}
                </div>

                <div style="padding: 16px 24px; background: #161616; border-top: 1px solid #2a2a2a; display: flex; justify-content: flex-end;">
                <button id="dev-modal-close" style="background: #27272a; color: #E0E0E0; border: 1px solid #3f3f46; padding: 8px 24px; border-radius: 6px; cursor: pointer; font-weight: 500; transition: all 0.2s;">Close</button>
                </div>
                </div>
                `;
                document.body.appendChild(overlay);

                const closeBtn = overlay.querySelector('#dev-modal-close');
                closeBtn.onmouseenter = () => closeBtn.style.background = '#3f3f46';
                closeBtn.onmouseleave = () => closeBtn.style.background = '#27272a';

                closeBtn.onclick = () => overlay.remove();
                overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    };

    // Context Menu Writing
    const handleContextMenu = (e) => {
        const msgNode = e.target.closest('div[id^="message-"]');
        lastRightClickedMessageId = msgNode ? msgNode.id.replace('message-', '') : null;
    };

    const createContextMenuItem = (text, iconSvg, onClickAction) => {
        const item = document.createElement('div');
        item.className = 'relative flex cursor-default select-none items-center rounded-lg px-3 py-2 text-sm outline-none transition-colors text-popover-foreground hover:bg-white/10 hover:text-foreground focus:bg-white/15 focus:text-foreground kloak-custom-context-btn';
        item.setAttribute('role', 'menuitem');
        item.tabIndex = -1;
        item.innerHTML = `${iconSvg}${text}`;

        item.addEventListener('click', () => {
            onClickAction();
            document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); // Close Radix
        });
        return item;
    };

    // Registration
    window.KloakAddons.registerAddon({
        id: ADDON_ID,
        name: 'Developer Toolkit',
        description: 'A powerful multitool for developers. View hidden user info and copy raw database IDs directly from the chat.',

        onEnable: () => {
            setupInterceptor();

            document.querySelectorAll('div[id^="message-"]').forEach(processMessage);

            domObserver = new MutationObserver((mutations) => {
                for (const mut of mutations) {
                    for (const node of mut.addedNodes) {
                        if (node.nodeType === 1) {
                            if (node.id && node.id.startsWith('message-')) processMessage(node);
                            else if (node.querySelectorAll) node.querySelectorAll('div[id^="message-"]').forEach(processMessage);
                        }
                    }
                }
            });
            domObserver.observe(document.body, { childList: true, subtree: true });

            document.addEventListener('contextmenu', handleContextMenu, true);

            rightClickObserver = new MutationObserver((mutations) => {
                for (const mut of mutations) {
                    for (const node of mut.addedNodes) {
                        if (node.nodeType === 1 && node.querySelector && lastRightClickedMessageId) {
                            const menu = node.querySelector('[data-radix-menu-content]') || (node.hasAttribute('data-radix-menu-content') ? node : null);

                            if (menu && !menu.querySelector('.kloak-custom-context-btn')) {
                                const msgData = messageCache.get(lastRightClickedMessageId);
                                const userId = msgData ? msgData.user_id : null;

                                const msgIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-hash w-4 h-4 mr-2"><line x1="4" x2="20" y1="9" y2="9"/><line x1="4" x2="20" y1="15" y2="15"/><line x1="10" x2="8" y1="3" y2="21"/><line x1="16" x2="14" y1="3" y2="21"/></svg>`;
                                menu.appendChild(createContextMenuItem('Copy Message ID', msgIcon, () => navigator.clipboard.writeText(lastRightClickedMessageId)));

                                if (userId) {
                                    const userIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user w-4 h-4 mr-2"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`;
                                    menu.appendChild(createContextMenuItem('Copy User ID', userIcon, () => navigator.clipboard.writeText(userId)));
                                }

                                const devIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-terminal w-4 h-4 mr-2"><polyline points="4 17 10 11 4 5"/><line x1="12" x2="20" y1="19" y2="19"/></svg>`;
                                menu.appendChild(createContextMenuItem('View User Info', devIcon, async () => {
                                    if (msgData && msgData.user) {
                                        showDeveloperModal(msgData.user);
                                    } else if (apiHeaders.apikey) {
                                        try {
                                            const res = await fetch(`${SUPABASE_URL}/rest/v1/messages?select=*,user:users(*)&id=eq.${lastRightClickedMessageId}`, { headers: apiHeaders });
                                            const data = await res.json();
                                            if (data && data[0] && data[0].user) {
                                                messageCache.set(data[0].id, data[0]);
                                                showDeveloperModal(data[0].user);
                                            }
                                        } catch (e) { console.error("Failed to fetch user data on the fly", e); }
                                    }
                                }));
                            }
                        }
                    }
                }
            });
            rightClickObserver.observe(document.body, { childList: true, subtree: false });
        },

        onDisable: () => {
            removeInterceptor();
            if (domObserver) domObserver.disconnect();
            if (rightClickObserver) rightClickObserver.disconnect();
            document.removeEventListener('contextmenu', handleContextMenu, true);

            document.querySelectorAll('.kloak-injected-msg-id, .kloak-injected-user-id').forEach(el => el.remove());
            document.querySelectorAll('div[id^="message-"]').forEach(msg => {
                delete msg.dataset.msgIdInjected;
                delete msg.dataset.usrIdInjected;
            });
        },

        renderSettings: (container) => {
            container.innerHTML = `
            <div style="color: #E0E0E0; display: flex; flex-direction: column; gap: 16px;">
            <p style="margin: 0; color: #a1a1aa;">Configure your Developer Toolkit preferences.</p>

            <label style="display: flex; align-items: center; gap: 12px; cursor: pointer;">
            <input type="checkbox" id="dt-show-ids" ${config.showIdsInChat ? 'checked' : ''} style="width: 16px; height: 16px; accent-color: #10b981;">
            <span style="font-size: 14px; color: #E0E0E0;">Show Message & User IDs in Chat</span>
            </label>

            <div style="display: flex; align-items: center; gap: 12px; margin-top: 8px; padding-top: 16px; border-top: 1px solid #27272a;">
            <button id="dt-save-btn" style="background: #10b981; color: #000; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-weight: 600;">Save Changes</button>
            <span id="dt-saved-msg" style="color: #10b981; font-size: 13px; font-weight: 500; opacity: 0; transition: opacity 0.2s;">✓ Saved</span>
            </div>
            </div>
            `;

            container.querySelector('#dt-save-btn').addEventListener('click', () => {
                config.showIdsInChat = container.querySelector('#dt-show-ids').checked;

                if (window.electronAPI && window.electronAPI.saveAddonConfig) {
                    window.electronAPI.saveAddonConfig({ addonId: ADDON_ID, data: config });
                    const msg = container.querySelector('#dt-saved-msg');
                    msg.style.opacity = '1';
                    setTimeout(() => msg.style.opacity = '0', 2000);
                }

                // Apply changes to the DOM
                if (config.showIdsInChat) {
                    document.querySelectorAll('div[id^="message-"]').forEach(n => {
                        // Clear the tracking flags so processMessage injects them again
                        delete n.dataset.msgIdInjected;
                        delete n.dataset.usrIdInjected;
                        processMessage(n);
                    });
                } else {
                    document.querySelectorAll('.kloak-injected-msg-id, .kloak-injected-user-id').forEach(el => el.remove());
                    document.querySelectorAll('div[id^="message-"]').forEach(msg => {
                        delete msg.dataset.msgIdInjected;
                        delete msg.dataset.usrIdInjected;
                    });
                }
            });
        }
    });
})();
